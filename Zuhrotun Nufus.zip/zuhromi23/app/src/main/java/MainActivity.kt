package com.zuhrotmi23

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var rvSepatu: RecyclerView
    private val list = ArrayList<Sepatu>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvSepatu = findViewById(R.id.rvSepatu)
        rvSepatu.setHasFixedSize(true)
        list.add(Sepatu("Sepatu Sport", "Sepatu untuk aktivitas olahraga", R.drawable.gambar1));
        list.add(Sepatu("Sepatu Formal", "Sepatu formal untuk acara resmi", R.drawable.gambar2));
        list.add(Sepatu("Sepatu Kasual", "Sepatu nyaman untuk penggunaan sehari-hari", R.drawable.gambar3));
        list.add(Sepatu("Sepatu High Heels", "Sepatu dengan hak tinggi untuk penampilan elegan", R.drawable.gambar4));
        list.add(Sepatu("Sepatu Boots", "Sepatu boot untuk musim dingin atau petualangan", R.drawable.gambar5));
        list.add(Sepatu("Sepatu Sneaker", "Sepatu sporty dengan desain modern", R.drawable.gambar6));
        list.add(Sepatu("Sepatu Sandal", "Sepatu sandal untuk cuaca panas", R.drawable.gambar7));
        list.add(Sepatu("Sepatu Running", "Sepatu khusus untuk lari dengan bantalan ekstra", R.drawable.gambar8));
        list.add(Sepatu("Sepatu Hiking", "Sepatu untuk kegiatan hiking dengan perlindungan ekstra", R.drawable.gambar9));
        list.add(Sepatu("Sepatu Slip-on", "Sepatu tanpa tali yang mudah dipakai dan dilepas", R.drawable.gambar10));

        showRecyclerList()
    }

    private fun showRecyclerList() {
        rvSepatu.layoutManager = LinearLayoutManager(this)
        val ListSepatuAdapter = SepatuAdapter<Any>(list)
        rvSepatu.adapter = ListSepatuAdapter
    }
}