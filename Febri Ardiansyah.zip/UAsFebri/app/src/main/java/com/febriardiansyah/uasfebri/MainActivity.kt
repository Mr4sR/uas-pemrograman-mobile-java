package com.febriardiansyah.uasfebri

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var rvPemainBola: RecyclerView
    private val list = ArrayList<PemainBola>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvPemainBola = findViewById(R.id.rvPemainBola)
        rvPemainBola.setHasFixedSize(true)
        list.add(PemainBola("Febri Hariyadi", "Pemain asal Indonesia", R.drawable.gambar1));
        list.add(PemainBola("Halland", "Pemain asal Norwegia", R.drawable.gambar2));
        list.add(PemainBola("Ricardo Kaka", "Pemain asal Brazil", R.drawable.gambar3));
        list.add(PemainBola("Mbappe", "Pemain asal Perancis", R.drawable.gambar4));
        list.add(PemainBola("Messi", "Pemain asal Argentina", R.drawable.gambar5));
        list.add(PemainBola("Neymar", "Pemain asal Brazil", R.drawable.gambar6));
        list.add(PemainBola("Dybala", "Pemain asal Argentina", R.drawable.gambar7));
        list.add(PemainBola("Ronaldo", "Pemain asal Portugal", R.drawable.gambar8));
        list.add(PemainBola("Yamal", "Pemain asal Spain", R.drawable.gambar9));
        list.add(PemainBola("Bellingham", "Pemain asal England", R.drawable.gambar10));
        showRecyclerList()
    }



    private fun showRecyclerList() {
        rvPemainBola.layoutManager = LinearLayoutManager(this)
        val listPemainAdapter = PemainBolaAdapter(list)
        rvPemainBola.adapter = listPemainAdapter
    }
}
