package com.febriardiansyah.uasfebri

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class PemainBola(
    val title: String,
    val description: String,
    val image: Int,
): Parcelable
