package com.example.uasafidha

import android.os.Parcelable

@Parcelize
data class Hero(
    val name: String,
    val description: String,
    val photo: Int
) : Parcelable
