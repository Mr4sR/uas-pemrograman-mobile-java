package com.example.aplikasiervin

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var rvSamsung: RecyclerView
    private val list = ArrayList<Samsung>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvSamsung = findViewById(R.id.RVsamsung)
        rvSamsung.setHasFixedSize(true)
        val list = mutableListOf<Samsung>()

        list.add(Samsung("Samsung Galaxy S23", "Flagship terbaru Samsung dengan kamera canggih dan performa tinggi.", R.drawable.gambar1))
        list.add(Samsung("Samsung Galaxy S22", "Smartphone premium dengan desain elegan dan kecepatan luar biasa.", R.drawable.gambar2))
        list.add(Samsung("Samsung Galaxy Note 20", "Fitur serba canggih dengan stylus S Pen untuk produktivitas lebih.", R.drawable.gambar3))
        list.add(Samsung("Samsung Galaxy A54", "HP menengah dengan kualitas kamera dan baterai tahan lama.", R.drawable.gambar4))
        list.add(Samsung("Samsung Galaxy Z Fold 5", "Ponsel lipat dengan layar besar yang bisa dilipat untuk kemudahan bawa.", R.drawable.gambar5))
        list.add(Samsung("Samsung Galaxy Z Flip 4", "Ponsel lipat dengan desain compact yang trendy dan teknologi layar fleksibel.", R.drawable.gambar10))
        list.add(Samsung("Samsung Galaxy A14", "Smartphone dengan harga terjangkau dan fitur dasar yang solid.", R.drawable.gambar6))
        list.add(Samsung("Samsung Galaxy M54", "Performa tinggi dengan baterai besar untuk penggunaan sehari-hari.", R.drawable.gambar7))
        list.add(Samsung("Samsung Galaxy S21 Ultra", "HP flagship dengan kamera 108 MP dan performa terbaik di kelasnya.", R.drawable.gambar8))
        list.add(Samsung("Samsung Galaxy A34", "HP kelas menengah dengan tampilan stylish dan kinerja optimal.", R.drawable.gambar9))

        showRecyclerList()
    }



    private fun showRecyclerList() {
        rvSamsung.layoutManager = LinearLayoutManager(this)
        val SamsungAdapter = ListSamsungAdapter(list)
        rvSamsung.adapter = SamsungAdapter
    }
}