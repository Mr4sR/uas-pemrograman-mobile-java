package com.pemorgeming.uasfera

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.Buah
import com.BuahAdapter
import com.ListrvBuahAdapter


class MainActivity : AppCompatActivity() {
    private lateinit var rvBuah: RecyclerView
    private val list = ArrayList<Buah>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvBuah = findViewById(R.id.rvBuah)
        rvBuah.setHasFixedSize(true)
        list.add(Buah("Anggur", "Buah segar dari kebun", R.drawable.gambar1));
        list.add(Buah("Apel", "Apel merah dari perkebunan", R.drawable.gambar2));
        list.add(Buah("Jeruk", "Jeruk manis penuh vitamin C", R.drawable.gambar3));
        list.add(Buah("Mangga", "Mangga harum khas tropis", R.drawable.gambar4));
        list.add(Buah("Pisang", "Pisang kaya akan potasium", R.drawable.gambar5));
        list.add(Buah("Nanas", "Nanas segar dari pegunungan", R.drawable.gambar6));
        list.add(Buah("Semangka", "Semangka merah manis dan segar", R.drawable.gambar7));
        list.add(Buah("Melon", "Melon hijau dengan rasa lezat", R.drawable.gambar8));
        list.add(Buah("Strawberry", "Strawberry segar dari dataran tinggi", R.drawable.gambar9));
        list.add(Buah("Kiwi", "Kiwi dengan rasa asam manis", R.drawable.gambar10));
        showRecyclerList()
    }



    private fun showRecyclerList() {
        rvBuah.layoutManager = LinearLayoutManager(this)
        val rvBuahAdapter = BuahAdapter(list)
        rvBuah.adapter = rvBuahAdapter
    }
}