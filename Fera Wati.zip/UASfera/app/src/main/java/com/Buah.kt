package com

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Buah(
    val title: String,
    val description: String,
    val image: Int,
): Parcelable

