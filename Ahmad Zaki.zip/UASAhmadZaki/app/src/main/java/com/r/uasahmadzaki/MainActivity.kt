package com.r.uasahmadzaki

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var rvkampus: RecyclerView
    private val list = ArrayList<kampus>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvkampus = findViewById(R.id.rvkampus)
        rvkampus.setHasFixedSize(true)
        list.add(kampus("Universitas Hasanuddin", "Kampus yang memfokuskan diri pada program studi kesehatan dan ilmu sosial", R.drawable.gambar1));
        list.add(kampus("Universitas Indonesia", "Kampus ternama dengan program studi unggulan", R.drawable.gambar2));
        list.add(kampus("Institut Teknologi Bandung", "Kampus dengan fokus pada teknologi dan inovasi", R.drawable.gambar3));
        list.add(kampus("Universitas Gadjah Mada", "Kampus dengan kekuatan dalam riset dan pengembangan", R.drawable.gambar4));
        list.add(kampus("Universitas Airlangga", "Kampus dengan reputasi di bidang kedokteran dan ilmu sosial", R.drawable.gambar5));
        list.add(kampus("Institut Pertanian Bogor", "Kampus yang unggul dalam bidang pertanian dan kehutanan", R.drawable.gambar6));
        list.add(kampus("Universitas Brawijaya", "Kampus dengan program studi di bidang teknik dan sains", R.drawable.gambar7));
        list.add(kampus("Universitas Padjadjaran", "Kampus dengan konsentrasi pada ilmu hukum dan ekonomi", R.drawable.gambar8));
        list.add(kampus("Universitas Sebelas Maret", "Kampus dengan program studi yang berfokus pada pengembangan sosial", R.drawable.gambar9));
        list.add(kampus("Universitas Diponegoro", "Kampus yang terkenal dengan program studi teknik dan ilmu politik", R.drawable.gambar10));



        showRecyclerList()
    }


    private fun showRecyclerList() {
        rvkampus.layoutManager = LinearLayoutManager(this)
        val listkampusAdapter = kampusadapter(list)
        rvkampus.adapter = listkampusAdapter
    }
}