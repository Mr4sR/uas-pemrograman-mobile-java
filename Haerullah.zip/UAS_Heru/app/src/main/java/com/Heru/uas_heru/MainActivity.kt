package com.Heru.uas_heru

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


class MainActivity : AppCompatActivity() {
    private lateinit var rvtoko: RecyclerView
    private val list = ArrayList<toko>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvtoko = findViewById(R.id.rvtoko)
        rvtoko.setHasFixedSize(true)
        list.add(toko("Sembako", "menyediakan kebutuhan sehari hari", R.drawable.gambar1))
        list.add(toko("Toko Elektronik", "menyediakan peralatan elektronik", R.drawable.gambar2));
        list.add(toko("Toko Pakaian", "menyediakan berbagai jenis pakaian", R.drawable.gambar3));
        list.add(toko("Toko Makanan", "menyediakan bahan makanan", R.drawable.gambar4));
        list.add(toko("Toko Perhiasan", "menyediakan perhiasan dan aksesoris", R.drawable.gambar5));
        list.add(toko("Toko Buku", "menyediakan buku dan alat tulis", R.drawable.gambar6));
        list.add(toko("Toko Sepatu", "menyediakan berbagai jenis sepatu", R.drawable.gambar7));
        list.add(toko("Toko Alat Rumah Tangga", "menyediakan alat-alat rumah tangga", R.drawable.gambar8));
        list.add(toko("Toko Kesehatan", "menyediakan produk kesehatan dan obat-obatan", R.drawable.gambar9));
        list.add(toko("Toko Mainan", "menyediakan mainan anak-anak", R.drawable.gambar10));
        showRecyclerList()
    }

    private fun showRecyclerList() {
        rvtoko.layoutManager = LinearLayoutManager(this)
        val listtokoAdapter = ListtokoAdapter(list)
        rvtoko.adapter = listtokoAdapter
    }
}