package com.ahmadzaki.tiyasvirgiantoro

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.febriardiansyah.uasfebri.R

class MainActivity : AppCompatActivity() {
    private lateinit var rvHeroMobilLegend: RecyclerView
    private val list = ArrayList<HeroMobilLegend>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvHeroMobilLegend = findViewById(R.id.rvHeroMobilLegendMobilLegendMobilLegend)
        rvHeroMobilLegend.setHasFixedSize(true)
        list.add(HeroMobilLegend("Selena", "Bisa ngejurus Lele gess", R.drawable.heroselena));
        list.add(HeroMobilLegend("Franko", "Bisa lempar pukulan maut ke musuh", R.drawable.herofrancko));
        list.add(HeroMobilLegend("Vexana", "Pembunuh tangguh dengan kecepatan tinggi", R.drawable.herovexana));
        list.add(HeroMobilLegend("Alukard", "Menembak musuh dengan jarak jauh", R.drawable.heroalukard));
        list.add(HeroMobilLegend("Karmila", "Assassin dengan serangan mematikan", R.drawable.herokarmila));
        list.add(HeroMobilLegend("Silvana", "Shield kuat dan serangan yang mematikan", R.drawable.herosilvana));
        list.add(HeroMobilLegend("Miya", "Terbang bebas dengan kabel", R.drawable.gambarmobiligendmiya));
        list.add(HeroMobilLegend("Naruto", "Pembunuh jarak jauh dengan senjata api", R.drawable.gambarnaruto));
        list.add(HeroMobilLegend("Pelangi", "Membombardir musuh dengan tembakan kuat", R.drawable.pelangibulat));
        list.add(HeroMobilLegend("Angka", "Pahlawan dengan kekuatan laut", R.drawable.angka));

        showRecyclerList()
    }



    private fun showRecyclerList() {
        rvHeroMobilLegend.layoutManager = LinearLayoutManager(this)
        val listHeroMobilLegendAdapter = HeroMobilLegendAdapter(list)
        rvHeroMobilLegend.adapter = listHeroMobilLegendAdapter
    }
}