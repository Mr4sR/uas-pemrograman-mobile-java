package com.ahmadzaki.tiyasvirgiantoro

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class HeroMobilLegend(
    val title: String,
    val desription: String,
    val image: Int,
): Parcelable
