
data class Item(
    val title: String,
    val logo: Int,
    val overview: String
)