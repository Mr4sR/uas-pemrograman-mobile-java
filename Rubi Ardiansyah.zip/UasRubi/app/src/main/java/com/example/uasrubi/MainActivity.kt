package com.example.uasrubi

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var rvMinuman: RecyclerView
    private val list = ArrayList<Minuman>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvMinuman = findViewById(R.id.rvMinuman)
        rvMinuman.setHasFixedSize(true)
        list.add(Minuman("Es Seger Mas R", "Rasa Capucino", R.drawable.minuman1))
        list.add(Minuman("Es Seger Mas R", "Rasa Red Velvet", R.drawable.minuman2))
        list.add(Minuman("Es Seger Mas R", "Rasa Original", R.drawable.minuman3))
        list.add(Minuman("Es Seger Mas R", "Rasa Mocca", R.drawable.minuman4))
        list.add(Minuman("Es Seger Mas R", "Rasa Susu & Capucino", R.drawable.minuman5))
        list.add(Minuman("Es Seger Mas R", "Rasa Kopi Americano", R.drawable.minuman6))
        list.add(Minuman("Es Seger Mas R", "Rasa Strawberri", R.drawable.minuman7))
        list.add(Minuman("Es Seger Mas R", "Rasa Red Velvet & susu", R.drawable.minuman8))
        list.add(Minuman("Es Seger Mas R", "Rasa Vanilla", R.drawable.minuman9))
        list.add(Minuman("Es Seger Mas R", "Rasa Lemon", R.drawable.minuman10))
        showRecyclerList()
    }

    private fun showRecyclerList() {
        rvMinuman.layoutManager = LinearLayoutManager(this)
        val listMinumanAdapter = MinumanAdapter(list)
        rvMinuman.adapter = listMinumanAdapter
    }
}