package com.revan.uas

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.revan.uas.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var rvIndomie: RecyclerView
    private val list = ArrayList<Indomie>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvIndomie = findViewById(R.id.rvIndomie)
        rvIndomie.setHasFixedSize(true)
        list.add(Indomie("Indomie Goreng", "Mie Goreng Dengan Rasa Original Enak Dan Simpel", R.drawable.mie1))
        list.add(Indomie("Indomie Soto Ayam", "Mie Kuah Dengan Rasa Soto Ayam Enak Dan Simpel", R.drawable.mie2))
        list.add(Indomie("Indomie Ayam Bawang", "Mie Kuah Dengan Rasa Ayam Bawang Enak Dan Simpel", R.drawable.mie3))
        list.add(Indomie("Indomie Kari Ayam", "Mie Kuah Dengan Rasa Kari Ayam Enak Dan Simpel", R.drawable.mie4))
        list.add(Indomie("Indomie Soto Lamongan", "Mie Kuah Dengan Rasa Soto Lamongan Enak Dan Simpel", R.drawable.mie5))
        list.add(Indomie("Indomie Goreng Ayam Geprek", "Mie Goreng Dengan Rasa Ayam Geprek Enak Dan Simpel", R.drawable.mie6))
        list.add(Indomie("Indomie Goreng Rica Rica", "Mie Goreng Dengan Rasa Sambal Rica Rica Enak Dan Simpel", R.drawable.mie7))
        list.add(Indomie("Indomie Goreng Rendang", "Mie Goreng Dengan Rasa Rendang Enak Dan Simpel", R.drawable.mie8))
        list.add(Indomie("Indomie Goreng Aceh", "Mie Goreng Dengan Rasa Otentik Dari Aceh, Enak Dan Simpel", R.drawable.mie9))
        list.add(Indomie("Indomie Soto Padang", "Mie Kuah Dengan Rasa Soto Lamongan Enak Dan Simpel", R.drawable.mie10))
        showRecyclerList()
    }

    private fun showRecyclerList() {
        rvIndomie.layoutManager = LinearLayoutManager(this)
        val listIndomieAdapter = IndomieAdapter(list)
        rvIndomie.adapter = listIndomieAdapter
    }
}