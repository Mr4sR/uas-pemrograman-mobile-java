package com.rosaauliyah.manajemeninformatika.uas_rosaauliyah

import android.os.Parcel
import android.os.Parcelable
import androidx.annotation.DrawableRes

data class Univ(
    val id: String,
    val name: String,
    val email: String,
    val web: String,
    @DrawableRes val logo: Int
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readInt()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(id)
        parcel.writeString(name)
        parcel.writeString(email)
        parcel.writeString(web)
        parcel.writeInt(logo)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<Univ> {
        override fun createFromParcel(parcel: Parcel): Univ = Univ(parcel)
        override fun newArray(size: Int): Array<Univ?> = arrayOfNulls(size)
    }
}
