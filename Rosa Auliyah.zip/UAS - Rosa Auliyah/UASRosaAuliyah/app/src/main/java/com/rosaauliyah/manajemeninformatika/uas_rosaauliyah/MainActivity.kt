package com.rosaauliyah.manajemeninformatika.uas_rosaauliyah

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private val listUniv = mutableListOf<Univ>()
    private lateinit var namaUniv: RecyclerView
    private lateinit var univAdapter: UnivAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val name = findViewById<ImageView>(R.id.user)
        name.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }

        // Inisialisasi Adapter
        univAdapter = UnivAdapter()

        namaUniv = findViewById(R.id.univ)
        namaUniv.layoutManager = LinearLayoutManager(this)
        namaUniv.adapter = univAdapter

        // Menambahkan data universitas dengan email dan website (urutan parameter diperbaiki)
        listUniv.addAll(
            listOf(
                Univ("1", "Universitas Indonesia", "info@ui.ac.id", "https://www.ui.ac.id", R.drawable.logo_ui),
                Univ("2", "Universitas Gajah Mada", "humas@ugm.ac.id", "https://www.ugm.ac.id", R.drawable.logo_ugm),
                Univ("3", "Institut Teknologi Bandung", "info@itb.ac.id", "https://www.itb.ac.id", R.drawable.logo_itb),
                Univ("4", "Universitas Airlangga", "humas@unair.ac.id", "https://www.unair.ac.id", R.drawable.logo_unair),
                Univ("5", "Universitas Brawijaya", "info@ub.ac.id", "https://www.ub.ac.id", R.drawable.logo_unbraw),
                Univ("6", "IPB University", "ask@apps.ipb.ac.id", "https://www.ipb.ac.id", R.drawable.logo_ipb),
                Univ("7", "Universitas Sebelas Maret", "info@uns.ac.id", "https://www.uns.ac.id", R.drawable.logo_uns),
                Univ("8", "Institut Teknologi Sepuluh Nopember", "humas@its.ac.id", "https://www.its.ac.id", R.drawable.logo_its),
                Univ("9", "Universitas Padjadjaran", "info@unpad.ac.id", "https://www.unpad.ac.id", R.drawable.logo_unpad),
                Univ("10", "Universitas Diponegoro", "humas@undip.ac.id", "https://www.undip.ac.id", R.drawable.logo_undip)
            )
        )

        // Set data ke adapter
        univAdapter.submitList(listUniv)

        fun navigateToDetail(univ: Univ) {
            val intent = when (univ.id) {
                "1" -> Intent(this, UI_Activity::class.java)
                "2" -> Intent(this, UGM_Activity::class.java)
                "3" -> Intent(this, ITB_Activity::class.java)
                "4" -> Intent(this, UNAIR_Activity::class.java)
                "5" -> Intent(this, UNBRAW_Activity::class.java)
                "6" -> Intent(this, IPB_Activity::class.java)
                "7" -> Intent(this, UNS_Activity::class.java)
                "8" -> Intent(this, ITS_Activity::class.java)
                "9" -> Intent(this, UNPAD_Activity::class.java)
                "10" -> Intent(this, UNDIP_Activity::class.java)
                else -> null
            }
            intent?.apply {
                putExtra("ID", univ.id)
                putExtra("NAME", univ.name)
                putExtra("EMAIL", univ.email)
                putExtra("WEBSITE", univ.web)
                putExtra("LOGO", univ.logo)
                startActivity(this)
            }
        }

    }
}
