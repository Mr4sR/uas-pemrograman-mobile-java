package com.aris.myapplication

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var rvbuku: RecyclerView
    private val list = ArrayList<buku>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvbuku = findViewById(R.id.rvBuku)
        rvbuku.setHasFixedSize(true)
        list.add(buku("Panggil Aku Kartini Saja", "Buku Dari Pramoedya Ananta Toer", R.drawable.gambar1))
        list.add(buku("Kerancuan Filsafat", "Buku Dari Imam Al-Gazali", R.drawable.gambar2))
        list.add(buku("Madilog", "Buku Dari Tan Malaka", R.drawable.gambar3))
        list.add(buku("Tuhan Maha Asyik", "Buku Dari Sujiwo Tejo", R.drawable.gambar4))
        list.add(buku("Kitab Firasat", "Buku Dari Imam Fakhruddin Ar-Razi", R.drawable.gambar5))
        list.add(buku("Filosofi Teras", "Buku Dari Henry Manampiring", R.drawable.gambar6))
        list.add(buku("Buya Hamka", "Buku Dari Dadi Purnama Eksan", R.drawable.gambar7))
        list.add(buku("Gadis Kretek", "Buku Dari Ratih Kumala", R.drawable.gambar8))
        list.add(buku("Aku Menulis Maka Aku Ada", "Buku Dari Kang Maman", R.drawable.gambar9))
        list.add(buku("Perang Baratayudha", "Buku Dari Zulfan Arif", R.drawable.gambar10))
        showRecyclerList()
    }

    private fun showRecyclerList() {
        rvbuku.layoutManager = LinearLayoutManager(this)
        val listbukuAdapter = ListbukuAdapter(list)
        rvbuku.adapter = listbukuAdapter
    }
}