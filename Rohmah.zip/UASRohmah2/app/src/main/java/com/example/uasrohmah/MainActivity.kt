package com.example.uasrohmah

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var rvListWarteg: RecyclerView
    private val list = ArrayList<Warteg>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvListWarteg = findViewById(R.id.rvListWarteg)
        rvListWarteg.setHasFixedSize(true)
        list.add(Warteg ("Ayam Bakar", "Warteg Ayam Bakar Yang Nikmat Sekali ", R.drawable.padang1))
        list.add(Warteg("Nasi Uduk", "Warteg Sederhana Banyak Pilihan Nikmat", R.drawable.padang2 ));
        list.add(Warteg("Ikan Goreng", "Warteg Nikmat Dan lezat Menggugah Selera", R.drawable.padang3));
        list.add(Warteg("Tempe Orek", "Warteg Maju Jaya Dan lezat Menggugah Selera", R.drawable.padang4));
        list.add(Warteg("Tahu Bacem", "Warteg Barokah Dan lezat Menggugah Selera", R.drawable.padang5));
        list.add(Warteg("Sayur Asem", "Warteg MakmurDan lezat Menggugah Selera", R.drawable.padang6));
        list.add(Warteg("Soto Ayam", "Warteg SejahteraDan lezat Menggugah Selera", R.drawable.padang7));
        list.add(Warteg("Telur Balado", "Warteg Podo Moro Dan lezat Menggugah Selera", R.drawable.padang8));
        list.add(Warteg("Rendang Daging", "Warteg Minang Dan lezat Menggugah Selera", R.drawable.padang9));
        list.add(Warteg("Cah Kangkung", "Warteg Hijau Dan lezat Menggugah Selera", R.drawable.padang10));
        showRecyclerList()
    }

    private fun showRecyclerList() {
        rvListWarteg.layoutManager = LinearLayoutManager(this)
        val listWartegAdapter = ListWartegAdapter(list)
        rvListWarteg.adapter = listWartegAdapter
    }
}