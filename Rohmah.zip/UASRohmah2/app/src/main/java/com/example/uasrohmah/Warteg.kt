package com.example.uasrohmah

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Warteg(
    val title: String,
    val description: String,
    val photo: Int
): Parcelable
