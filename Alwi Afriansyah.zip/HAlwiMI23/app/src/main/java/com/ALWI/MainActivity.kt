package com.ALWI

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
class MainActivity : AppCompatActivity() {
    private lateinit var rvMataKuliah: RecyclerView
    private val list = ArrayList<MataKuliah>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvMataKuliah = findViewById(R.id.rvKuliah)
        rvMataKuliah.setHasFixedSize(true)
        list.add(MataKuliah("Bahasa Sunda", "Mata Kuliahnya Mr El Punya", R.drawable.gambar1))
        list.add(MataKuliah("Bahasa Babasan", "Mata Kuliahnya Mr Al Punya", R.drawable.gambar2))
        list.add(MataKuliah("Bahasa Korea", "Mata Kuliahnya Mr Ul Punya", R.drawable.gambar3))
        list.add(MataKuliah("Bahasa Thailand", "Mata Kuliahnya Mr Ol Punya", R.drawable.gambar4))
        list.add(MataKuliah("Bahasa Cilegon", "Mata Kuliahnya Mr ml Punya", R.drawable.gambar5))
        list.add(MataKuliah("Bahasa Serang", "Mata Kuliahnya Mr Ql Punya", R.drawable.gambar6))
        list.add(MataKuliah("Bahasa Jerman", "Mata Kuliahnya Mr tl Punya", R.drawable.gambar7))
        list.add(MataKuliah("Bahasa Indonesia", "Mata Kuliahnya Hr El Punya", R.drawable.gambar8))
        list.add(MataKuliah("Bahasa Jepang", "Mata Kuliahnya Mr pl Punya", R.drawable.gambar9))
        list.add(MataKuliah("Bahasa Inggris", "Mata Kuliahnya Mr Al Punya", R.drawable.gambar10))
        showRecyclerList()
    }



    private fun showRecyclerList() {
        rvMataKuliah.layoutManager = LinearLayoutManager(this)
        val listMataKuliahAdapter = MataKuliahAdapter(list)
        rvMataKuliah.adapter = listMataKuliahAdapter
    }
}