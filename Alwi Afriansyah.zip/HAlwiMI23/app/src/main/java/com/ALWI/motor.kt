package com.ALWI

@parcelize
data class motor(
    val title: String,
    val origin: String,
    val image: Int,
) :    Parcelable
)

