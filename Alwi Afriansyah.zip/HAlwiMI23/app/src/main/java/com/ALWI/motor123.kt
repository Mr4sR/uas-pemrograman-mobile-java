package com.example.project

import android.view.LayoutInflater
import android.view.viewGroup
import androidx.recyclervMataKuliahiew.widget.RecyclervMataKuliahiew
import com.ALWI.uasALWI.databinding.itemmotorBinding

class motor123 {
    val data : ArrayList<motor123>
    val onClick : (motor123) > Unit
    )
    }



