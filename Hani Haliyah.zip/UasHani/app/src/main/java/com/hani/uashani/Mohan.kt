package com.hani.uashani

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Mohan(
    val title : String,
    val description : String,
    val image : Int,

): Parcelable
