package com.hani.uashani

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var rvMohan: RecyclerView
    private val list = ArrayList<Mohan>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvMohan = findViewById(R.id.rvMohan )
        rvMohan.setHasFixedSize(true)
        list.add(Mohan ("Mohan Cakep", "Mohan Punya Hani", R.drawable.gambar1  ))
        list.add(Mohan ("Mohan Ganteng", "Mohan Punya Hani", R.drawable.gambar2  ))
        list.add(Mohan ("Mohan Cute", "Mohan Punya Hani", R.drawable.gambar3  ))
        list.add(Mohan ("Mohan Bigboy", "Mohan Punya Hani", R.drawable.gambar4  ))
        list.add(Mohan ("Mohan Handsome", "Mohan Punya Hani", R.drawable.gambar5  ))
        list.add(Mohan ("Mohan Aku", "Mohan Punya Hani", R.drawable.gambar6  ))
        list.add(Mohan ("Mohan Lucu", "Mohan Punya Hani", R.drawable.gambar7  ))
        list.add(Mohan ("Mohan Idaman", "Mohan Punya Hani", R.drawable.gambar8 ))
        list.add(Mohan ("Mohan Hani", "Mohan Punya Hani", R.drawable.gambar9  ))
        list.add(Mohan ("Mohan Haliyah", "Mohan Punya Hani", R.drawable.gambar10 ))
        showRecyclerList()
    }



    private fun showRecyclerList() {
        rvMohan.layoutManager = LinearLayoutManager(this)
        val listMohanAdapter = MohanAdapter(list)
        rvMohan.adapter = listMohanAdapter
    }
}