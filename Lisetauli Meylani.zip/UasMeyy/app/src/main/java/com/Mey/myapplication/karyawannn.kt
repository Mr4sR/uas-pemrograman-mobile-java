package com.Mey.myapplication

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class karyawannnnn(
    val name: String,
    val description: String,
    val photo: Int
) : Parcelable