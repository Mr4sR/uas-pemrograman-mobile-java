package com.Mey.myapplication

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var rvkaryawannnnn: RecyclerView
    private val list = ArrayList<karyawannnnn>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvkaryawannnnn = findViewById(R.id.rvkaryawannnnn)
        rvkaryawannnnn.setHasFixedSize(true)
        list.add(karyawannnnn("Meeting", "kumpulan karyawan", R.drawable.gambar1))
        list.add(karyawannnnn("Bekerja", "karyawannn sedang berdiskusi", R.drawable.gambar2))
        list.add(karyawannnnn("Berfoto", "karyawannn mengangkat jempol", R.drawable.gambar3))
        list.add(karyawannnnn("Lembur", "karyawannn sedang menelepon costumer", R.drawable.gambar4))
        list.add(karyawannnnn("Training", "karyawannn Berfoto ", R.drawable.gambar5))
        list.add(karyawannnnn("Bos", "Bos Karyawan", R.drawable.gambar6))
        list.add(karyawannnnn("Diskusi Tim", "karyawannn berdiskusi dengan tim", R.drawable.gambar7))
        list.add(karyawannnnn("Meeting Tim", "karyawannn sedang melakukan rapat tim", R.drawable.gambar8))
        list.add(karyawannnnn("rapat", "karyawannn sedang membuat rapat kecil", R.drawable.gambar9))
        list.add(karyawannnnn("Pas foto", "karyawannn melakukan foto untuk id card", R.drawable.gambar10))


    }

    private fun showRecyclerList() {
        rvkaryawannnnn.layoutManager = LinearLayoutManager(this)
        val listkaryawannnnnAdapter = karyawannnnnAdapter(list)
        rvkaryawannnnn.adapter = listkaryawannnnnAdapter
    }
}