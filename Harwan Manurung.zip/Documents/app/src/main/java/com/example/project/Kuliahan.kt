package com.example.project

import android.os.Parcelable
import kotlinx.parcelize.Parcelize


@Parcelize
data class Kuliahan(
    val name: String,
    val description: String,
    val photo: Int
) : Parcelable
