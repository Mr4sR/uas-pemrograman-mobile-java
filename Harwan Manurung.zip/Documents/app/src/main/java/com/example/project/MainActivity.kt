package com.example.project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var rvKuliahan: RecyclerView
    private val list = ArrayList<Kuliahan>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvKuliahan = findViewById(R.id.rvKuliahan)
        rvKuliahan.setHasFixedSize(true)
        list.add(Kuliahan("Bahasa dewasa", "Mata Kuliahnya Mr al Punya", R.drawable.gambar1))
        list.add(Kuliahan("Bahasa tiktok", "Mata Kuliahnya Mr ol Punya", R.drawable.gambar2))
        list.add(Kuliahan("Bahasa anak", "Mata Kuliahnya Mr il Punya", R.drawable.gambar3))
        list.add(Kuliahan("Bahasa kampung", "Mata Kuliahnya Mr ul Punya", R.drawable.gambar4))
        list.add(Kuliahan("Bahasa jerman", "Mata Kuliahnya Mr El Punya", R.drawable.gambar5))
        list.add(Kuliahan("Bahasa mandarin", "Mata Kuliahnya Mr pl Punya", R.drawable.gambar6))
        list.add(Kuliahan("Bahasa Inggris", "Mata Kuliahnya Mr ml Punya", R.drawable.gambar7))
        list.add(Kuliahan("Bahasa Indonesia", "Mata Kuliahnya kl rl Punya", R.drawable.gambar8))
        list.add(Kuliahan("matematika", "Mata Kuliahnya Mr tl Punya", R.drawable.gambar9))
        list.add(Kuliahan("Bahasa Inggris", "Mata Kuliahnya Mr wl Punya", R.drawable.gambar10))
        showRecyclerList()
    }



    private fun showRecyclerList() {
        rvKuliahan.layoutManager = LinearLayoutManager(this)
        val listKuliahanAdapter = KuliahanAdapter(list)
        rvKuliahan.adapter = listKuliahanAdapter
    }
}