package com.sopiyah.sopiyah

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Anime(
    val tittle: String,
    val description: String,
    val image: Int,
): Parcelable
