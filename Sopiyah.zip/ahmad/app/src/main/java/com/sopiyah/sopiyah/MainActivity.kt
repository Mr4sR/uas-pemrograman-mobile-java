package com.sopiyah.sopiyah

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var rvAnime: RecyclerView
    private val list = ArrayList<Anime>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvAnime = findViewById(R.id.rvAnime)
        rvAnime.setHasFixedSize(true)
        list.add(Anime("One Piece", "One Piece adalah anime yang menceritakan perjalanan Monkey D. Luffy, seorang pemuda dengan tubuh elastis karena memakan buah iblis, bersama kru bajak lautnya untuk mencari harta karun legendaris, One Piece. Luffy berambisi menjadi Raja Bajak Laut, menghadapi berbagai petualangan, musuh kuat, dan menjalin persahabatan dalam perjalanan panjang melintasi lautan", R.drawable.gambar1))
        list.add(Anime("One Punch Man", "One Punch Man adalah anime yang mengikuti Saitama, seorang pria yang sangat kuat hingga bisa mengalahkan musuh dengan satu pukulan. Meskipun memiliki kekuatan luar biasa, Saitama merasa bosan karena tidak ada lawan yang bisa menantangnya. Ia bergabung dengan Asosiasi Pahlawan untuk mencari tantangan, tetapi justru menghadapi kesulitan dalam mendapatkan pengakuan, karena banyak orang meremehkan kemampuannya yang terlalu hebat.", R.drawable.gambar2))
        list.add(Anime("Demon Slayer", "Demon Slayer (Kimetsu no Yaiba) adalah anime yang mengikuti perjalanan Tanjiro Kamado, seorang pemuda yang menjadi pembasmi iblis setelah keluarganya dibunuh oleh iblis, dan adiknya, Nezuko, berubah menjadi iblis. Tanjiro bergabung dengan Demon Slayer Corps untuk mencari cara mengembalikan Nezuko menjadi manusia dan membasmi iblis yang mengancam dunia. Anime ini dikenal dengan animasi yang luar biasa dan pertarungan yang intens", R.drawable.gambar3))
        list.add(Anime("Jujutsu Kaisen", "Jujutsu Kaisen adalah anime yang bercerita tentang Yuji Itadori, seorang remaja dengan kekuatan fisik luar biasa yang terlibat dalam dunia ilmu sihir setelah memakan jari iblis kuat bernama Ryomen Sukuna. Untuk melindungi teman-temannya dan dunia, Yuji bergabung dengan Jujutsu High, tempat para penyihir dilatih untuk melawan iblis dan kutukan. Anime ini penuh dengan pertarungan seru, kekuatan magis, dan tema tentang kehidupan serta kematian.", R.drawable.gambar4))
        list.add(Anime("Boruto: Naruto Next Generations", "Boruto: Naruto Next Generations adalah anime yang melanjutkan kisah dari Naruto, fokus pada Boruto Uzumaki, putra Naruto Uzumaki yang kini menjadi Hokage. Boruto berusaha menemukan jalannya sendiri sebagai ninja, sering kali merasa tertekan dengan bayang-bayang ayahnya. Anime ini mengikuti petualangan Boruto dan teman-temannya yang menghadapi ancaman baru, sekaligus menggali hubungan mereka dengan generasi ninja sebelumnya.", R.drawable.gambar5))
        list.add(Anime("Dandadan", "andadan bercerita tentang dua siswa yang terlibat dalam hal-hal absurd seputar alien dan hantu.Cerita bermula ketika Momo Ayase dipertemukan dengan Ken Okarun Takakura. Namun, keduanya justru tak dapat akur di momen perkenalan mereka sebab kepercayaan akan keberadaan entitas tertentu yang saling bertentan", R.drawable.gambar6))
        list.add(Anime("Chainsaw Man", "Chainsaw Man bercerita tentang Denji, pemuda miskin yang menjadi pemburu iblis untuk melunasi utang ayahnya. Setelah mati, tubuhnya digabung dengan anjing iblis bernama Pochita, memberinya kekuatan untuk berubah menjadi Chainsaw Man dengan gergaji mesin. Denji bergabung dengan organisasi pemburu iblis dan menghadapi berbagai bahaya sambil mencari kehidupan yang lebih baik", R.drawable.gambar7))
        list.add(Anime("Sakamoto Days", "Sakamoto Days adalah manga dan anime yang mengikuti Taro Sakamoto, seorang mantan pembunuh bayaran legendaris yang sangat kuat dan terkenal. Setelah pensiun, ia menjalani kehidupan normal sebagai pemilik toko swalayan. Namun, meskipun sudah meninggalkan dunia kejahatan, masa lalu Sakamoto terus menghantuinya, dan ia terpaksa terlibat kembali dalam berbagai konflik berbahaya, sambil berusaha menjaga keluarganya dan menjalani kehidupan yang tenang.", R.drawable.gambar8))
        list.add(Anime("Mob Psycho 100", "Mob Psycho 100 adalah anime yang mengikuti Shigeo Mob Kageyama, seorang remaja dengan kekuatan psikik luar biasa. Meskipun memiliki kemampuan yang sangat kuat, Mob berusaha menjalani kehidupan normal dan menghindari konflik. Ia bekerja untuk seorang penipu bernama Reigen, yang mengaku sebagai seorang ahli spiritual, meskipun ia tidak memiliki kekuatan sama sekali. Cerita berfokus pada perjuangan Mob untuk mengendalikan kekuatan emosionalnya, sambil menghadapi berbagai ancaman dan pertanyaan tentang identitas serta tujuan hidupnya", R.drawable.gambar9))
        list.add(Anime("Naruto", "Naruto adalah anime yang bercerita tentang Naruto Uzumaki, seorang ninja muda yang memiliki impian untuk menjadi Hokage, pemimpin desa ninja yang dihormati, meskipun ia awalnya dipandang sebelah mata oleh orang-orang di desanya. Naruto juga membawa kekuatan besar karena ada Kyuubi, rubah ekor sembilan, yang tersegel di dalam tubuhnya. Anime ini mengikuti perjalanan Naruto untuk membuktikan dirinya, menjalin persahabatan, dan melawan berbagai musuh kuat sambil menghadapi tantangan sebagai seorang ninja", R.drawable.gambar10))
        showRecyclerList()
    }


    private fun showRecyclerList() {
        rvAnime.layoutManager = LinearLayoutManager(this)
        val listAnimeAdapter = AnimeAdapter(list)
        rvAnime.adapter = listAnimeAdapter
    }
}