package com.ridodudin_uas

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ridho.ridodudin_uas.R

class MainActivity : AppCompatActivity() {
    private lateinit var rvMataPelajaran: RecyclerView
    private val list = ArrayList<MataPelajaran>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvMataPelajaran = findViewById(R.id.rvMataPelajaran)
        rvMataPelajaran.setHasFixedSize(true)
        list.add(MataPelajaran("Kelas I", "Ibu Ma'ajah", R.drawable.gambar1));
        list.add(MataPelajaran("Kelas II", "Ibu Khosiah", R.drawable.gambar2));
        list.add(MataPelajaran("Kelas III", "Ibu Mutmainah", R.drawable.gambar3));
        list.add(MataPelajaran("Kelas IV", "Ibu Fatmawati", R.drawable.gambar4));
        list.add(MataPelajaran("Kelas V", "Bapak Holilulloh", R.drawable.gambar5));
        list.add(MataPelajaran("Kelas VI", "Bapak Suhadi", R.drawable.gambar6));
        list.add(MataPelajaran("Kelas XI", "Bapak Ustadz Khotib", R.drawable.gambar7));
        list.add(MataPelajaran("Kelas XII", "Bapak Ferry", R.drawable.gambar8));
        list.add(MataPelajaran("Kelas XIII", "Ibu Febrianti", R.drawable.gambar9));
        list.add(MataPelajaran("Kelas XIV", "Ibu Fatonah", R.drawable.gambar10));
        
        showRecyclerList()
    }



    private fun showRecyclerList() {
        rvMataPelajaran.layoutManager = LinearLayoutManager(this)
        val listMataPelajaranAdapter = MataPelajaranAdapter(list)
        rvMataPelajaran.adapter = listMataPelajaranAdapter
    }
}