package com.ridodudin_uas

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class MataPelajaran(
    val name: String,
    val description: String,
    val photo: Int
) : Parcelable
